Auto Reels Master - Termux

Place this folder in ~/ and run:

pip install -r requirements.txt
# put mp3 files in the musics/ folder if you want
python3 generate_full_reel.py

Configure BOT_TOKEN and CHAT_ID in ~/auto_reels/.env or the .env inside the folder.
