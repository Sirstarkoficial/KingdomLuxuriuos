#!/data/data/com.termux/files/usr/bin/env bash
cd ~/auto_reels
python3 generate_full_reel.py >> ~/auto_reels/run.log 2>&1
