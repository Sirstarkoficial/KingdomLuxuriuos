#!/usr/bin/env python3
# generate_full_reel.py
# Auto Reels: generate videos, subtitles, hooks, images (IA optional), and send to Telegram.
# Requirements: python libs in requirements.txt, ffmpeg installed.
# Place music mp3 files in music/ (optional). If no IA tokens, script uses Pillow fallback images.

import os, sys, re, json, random, subprocess, time, hashlib
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from gtts import gTTS
from PIL import Image, ImageDraw, ImageFont
import requests
import shlex
import base64

ROOT = Path.home() / "auto_reels"
MUSIC_DIR = ROOT / "music"
OUT_DIR = ROOT / "out"
TMP_DIR = ROOT / "tmp"
for p in (MUSIC_DIR, OUT_DIR, TMP_DIR):
    p.mkdir(parents=True, exist_ok=True)

# Load .env
ENV_PATH = ROOT / ".env"
if ENV_PATH.exists():
    load_dotenv(dotenv_path=str(ENV_PATH))

# Config
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
CHAT_ID = os.getenv("CHAT_ID", "").strip()
VOICE_LANG = os.getenv("VOICE_LANG", "es")
VIDEO_W = int(os.getenv("VIDEO_WIDTH", "1080"))
VIDEO_H = int(os.getenv("VIDEO_HEIGHT", "1920"))
MUSIC_VOLUME = float(os.getenv("MUSIC_VOLUME", "0.25"))
VOICE_VOLUME = float(os.getenv("VOICE_VOLUME", "1.0"))
TOPICS_FILE = Path(os.getenv("TOPICS_FILE", str(ROOT / "topics.txt")))
REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN", "").strip()
HF_API_TOKEN = os.getenv("HF_API_TOKEN", "").strip()
AUTOMATIC1111_URL = os.getenv("AUTOMATIC1111_LOCAL_URL", "").strip()

FONT_PATHS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/system/fonts/DroidSansFallback.ttf"]

# Helpers
def run(cmd, capture=False):
    if isinstance(cmd, (list,tuple)):
        cmd = " ".join(shlex.quote(str(x)) for x in cmd)
    print("[CMD]", cmd)
    try:
        if capture:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
            return out.decode('utf-8', errors='ignore').strip()
        else:
            subprocess.check_call(cmd, shell=True)
            return True
    except subprocess.CalledProcessError as e:
        print("Command failed:", e)
        if capture:
            return e.output.decode('utf-8', errors='ignore')
        return False

SPANISH_STOPWORDS = set('de la que el en y a los del se las por un para con no una su al lo como más pero sus le ya o este sí porque esta entre cuando muy sin sobre también me hasta hay donde quien desde todo nos durante todos uno les ni contra otros ese eso había ante ellos e esto mí antes algunos qué unos yo otro otras otra él tanto esa unos hacer tanto bien poco ella estar tener esos ahora cada vida poco ellos años tanto hombre parte así sobre'.split())

def clean_words(text):
    text = text.lower()
    text = re.sub(r"[^a-záéíóúñü0-9\s]", " ", text)
    words = [w for w in text.split() if w and w not in SPANISH_STOPWORDS and len(w) > 2]
    return words

def top_keywords(text, n=6):
    words = clean_words(text)
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    items = sorted(freq.items(), key=lambda x: (-x[1], x[0]))
    return [w for w,_ in items[:n]]

# Auto topics
TOPICS_SEED = [
    "productividad", "marketing", "crecimiento en redes sociales",
    "hábitos matutinos", "edición rápida", "ideas de contenido",
    "negocios online", "motivación", "trucos de vida", "productividad personal"
]

def auto_generate_topic():
    day_hash = int(hashlib.sha1(datetime.now().strftime("%Y-%m-%d").encode()).hexdigest()[:8], 16)
    random.seed(day_hash + int(time.time()//3600))
    seed = random.choice(TOPICS_SEED)
    templates = [
        "Cómo mejorar {} en 3 pasos",
        "Errores comunes en {} y cómo arreglarlos",
        "Ideas rápidas para {}",
        "Estrategias de {} que funcionan hoy",
        "Guía práctica de {} para principiantes"
    ]
    tpl = random.choice(templates)
    topic = tpl.format(seed)
    return re.sub(r"\s{2,}", " ", topic).strip()

# Script generator
DEFAULT_TOPICS = [
    "productividad personal",
    "marketing en redes sociales",
    "ideas para contenido corto",
    "hábitos matutinos",
    "trucos de edición de video"
]

def load_topics():
    if TOPICS_FILE.exists():
        with open(TOPICS_FILE, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip()]
            if lines: return lines
    return DEFAULT_TOPICS

def generate_script(topic):
    intro = f"¿Sabías que sobre {topic} muchas personas cometen errores simples? Te lo explico rápido."
    bullets = [
        f"Primero: define un objetivo claro para {topic}.",
        f"Segundo: divide la acción en pasos pequeños y medibles.",
        f"Tercero: automatiza lo que puedas y repítelo cada día."
    ]
    cta = "Si te gustó esto, guarda el vídeo y sígueme para más."
    full = " ".join([intro] + bullets + [cta])
    title = f"{topic} - Tips rápidos"
    return title, full

def analyze_and_generate_hooks(script_text, topic):
    base_keywords = [
        "truco", "secreto", "error común", "rápido", "nadie te dice",
        "aprende esto", "descubre", "evita", "transforma"
    ]
    hooks = []
    hooks.append(f"Nadie te dice esto sobre {topic.lower()}…")
    hooks.append(f"El truco más rápido para mejorar tu {topic.lower()} HOY.")
    hooks.append(f"Esto te va a doler… pero necesitas saberlo sobre {topic.lower()}.")
    hashtags = [
        "#Aprende", "#Consejos", "#Tips", "#Mindset", "#ParaTi", "#Reels",
        "#Motivacion", "#Mexico", f"#{topic.split()[0]}"
    ]
    return hooks, hashtags

# TTS
def text_to_speech(text, out_path, lang=VOICE_LANG):
    tts = gTTS(text, lang=lang)
    tts.save(str(out_path))
    return out_path

# Image creation (fallback)
def get_font(size=72):
    for p in FONT_PATHS:
        try:
            return ImageFont.truetype(p, size=size)
        except Exception:
            continue
    return ImageFont.load_default()

def create_centered_image(text, out_path, size=(VIDEO_W,VIDEO_H), title_mode=True):
    w,h = size
    bg = Image.new("RGB", size, color=(18,18,18) if title_mode else (12,12,40))
    draw = ImageDraw.Draw(bg)
    font = get_font(80 if title_mode else 96)
    words = text.split()
    lines,cur = [],""
    for word in words:
        if len(cur) + len(word) + 1 < 18:
            cur += (" " + word) if cur else word
        else:
            lines.append(cur); cur = word
    if cur: lines.append(cur)
    total_h = sum(draw.textsize(l, font=font)[1] + 12 for l in lines)
    y = (h - total_h)//2
    for line in lines[:5]:
        tw,th = draw.textsize(line, font=font)
        draw.text(((w-tw)//2, y), line, font=font, fill=(255,255,255))
        y += th + 12
    bg.save(out_path, quality=90)
    return out_path

# IA image generation (Replicate/HF/Automatic1111) - simplified
def generate_image_with_ia(prompt, out_path):
    out_path = Path(out_path)
    # Try Replicate
    if REPLICATE_API_TOKEN:
        try:
            print("Replicate integration not fully automated here. Skipping to HF/Automatic.")
        except Exception as e:
            print("Replicate error:", e)
    # Try Hugging Face simple inference (may return image bytes)
    if HF_API_TOKEN:
        try:
            print("Trying Hugging Face Inference...")
            hf_url = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2"
            headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}
            payload = {"inputs": prompt}
            resp = requests.post(hf_url, headers=headers, json=payload, timeout=120)
            if resp.status_code == 200 and resp.headers.get("content-type","").startswith("image"):
                out_path.write_bytes(resp.content)
                return str(out_path)
        except Exception as e:
            print("HuggingFace error:", e)
    # Try Automatic1111 local
    if AUTOMATIC1111_URL:
        try:
            api_url = AUTOMATIC1111_URL.rstrip("/") + "/sdapi/v1/txt2img"
            payload = {"prompt": prompt, "steps": 20, "width": 768, "height": 1024}
            rr = requests.post(api_url, json=payload, timeout=120)
            if rr.status_code == 200 and "images" in rr.json():
                img_b64 = rr.json()["images"][0]
                out_path.write_bytes(base64.b64decode(img_b64))
                return str(out_path)
        except Exception as e:
            print("Automatic1111 error:", e)
    # Fallback local
    print("No IA available or failed. Using Pillow fallback.")
    create_centered_image(prompt, out_path)
    return str(out_path)

# Audio helpers
def mix_audio(voice_mp3, music_mp3, out_mp3, music_vol=MUSIC_VOLUME, voice_vol=VOICE_VOLUME):
    if not music_mp3 or not Path(music_mp3).exists():
        cmd = f'ffmpeg -y -i "{voice_mp3}" -c:a libmp3lame -q:a 4 "{out_mp3}"'
        run(cmd)
        return out_mp3
    cmd = (
        f'ffmpeg -y -i "{voice_mp3}" -stream_loop -1 -i "{music_mp3}" '
        f'-filter_complex "[1:a]volume={music_vol}[m];[0:a]volume={voice_vol}[v];[v][m]amix=inputs=2:duration=first:dropout_transition=2[a]" '
        f'-map "[a]" -c:a libmp3lame -q:a 4 "{out_mp3}"'
    )
    run(cmd)
    return out_mp3

def get_audio_duration(path):
    cmd = f'ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "{path}"'
    out = run(cmd, capture=True)
    try:
        return float(out.strip().splitlines()[0])
    except Exception:
        return None

# Subtitles
def words_count(s): return len([w for w in re.split(r"\s+", s) if w])
def create_srt_from_script(script_text, audio_duration, srt_path):
    parts = [p.strip() for p in re.split(r'[\n\.!?]+', script_text) if p.strip()]
    if not parts:
        parts = [script_text]
    total_words = sum(words_count(p) for p in parts)
    wps = max(2.5, total_words / max(0.1, audio_duration))
    t_cursor = 0.5
    with open(srt_path, "w", encoding="utf-8") as f:
        idx = 1
        for part in parts:
            w = words_count(part)
            dur = max(0.8, w / wps)
            start = t_cursor
            end = start + dur
            def fmt(t):
                h = int(t//3600); m=int((t%3600)//60); s=int(t%60); ms=int((t - int(t))*1000)
                return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
            f.write(f"{idx}\n")
            f.write(f"{fmt(start)} --> {fmt(end)}\n")
            f.write(part + "\n\n")
            idx += 1
            t_cursor = end + 0.15
    return srt_path

# Video creation
def create_center_image_and_video(title, audio_path, out_video):
    img = TMP_DIR / f"img_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg"
    create_centered_image(title, img)
    dur = get_audio_duration(audio_path) or 10
    cmd = (
        f'ffmpeg -y -loop 1 -i "{img}" -i "{audio_path}" -c:v libx264 -tune stillimage '
        f'-vf "scale={VIDEO_W}:{VIDEO_H},format=yuv420p" -c:a aac -b:a 192k -shortest -movflags +faststart -t {dur} "{out_video}"'
    )
    run(cmd)
    return out_video

def make_hook_clip(hook_text, out_hook_mp4, seconds=3):
    hook_img = TMP_DIR / f"hook_img_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg"
    create_centered_image(hook_text, hook_img, title_mode=False)
    cmd = (
        f'ffmpeg -y -loop 1 -i "{hook_img}" -c:v libx264 -t {seconds} '
        f'-vf "scale={VIDEO_W}:{VIDEO_H},format=yuv420p,fade=t=in:st=0:d=0.5,fade=t=out:st={seconds-0.6}:d=0.6" '
        f'-pix_fmt yuv420p -movflags +faststart "{out_hook_mp4}"'
    )
    run(cmd)
    return out_hook_mp4

def burn_subtitles_to_video(input_video, srt_file, out_video):
    cmd = f'ffmpeg -y -i "{input_video}" -vf "subtitles={srt_file}:force_style=\\'FontName=DejaVu Sans,Fontsize=48,PrimaryColour=&H00FFFFFF&\\'" -c:a copy "{out_video}"'
    run(cmd)
    return out_video

def concat_videos_mp4(list_of_files, out_file):
    concat_txt = TMP_DIR / f"concat_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
    with open(concat_txt, "w", encoding="utf-8") as f:
        for p in list_of_files:
            f.write(f"file '{p}'\n")
    cmd = f'ffmpeg -y -f concat -safe 0 -i "{concat_txt}" -c copy "{out_file}"'
    run(cmd)
    return out_file

def send_to_telegram(file_path, caption=""):
    if not BOT_TOKEN or not CHAT_ID:
        print("BOT_TOKEN/CHAT_ID not configured. Skipping Telegram send.")
        return False
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    with open(file_path, "rb") as f:
        files = {"document": f}
        data = {"chat_id": CHAT_ID, "caption": caption}
        try:
            r = requests.post(url, data=data, files=files, timeout=240)
            print("Telegram status:", r.status_code, r.text[:200])
            return r.ok
        except Exception as e:
            print("Error sending Telegram:", e)
            return False

def create_full_reel(topic=None, send_telegram=True):
    topics = load_topics()
    topic = topic or auto_generate_topic()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    title, script = generate_script(topic)
    hooks, hashtags = analyze_and_generate_hooks(script, topic)
    meta = {"topic": topic, "title": title, "script": script, "timestamp": stamp, "hooks": hooks, "hashtags": hashtags}
    voice_file = TMP_DIR / f"voice_{stamp}.mp3"
    print("Generating TTS...")
    text_to_speech(script, voice_file, lang=VOICE_LANG)
    musics = list(MUSIC_DIR.glob("*.mp3"))
    music_choice = str(random.choice(musics)) if musics else None
    if not music_choice:
        silent = TMP_DIR / "silent_30s.mp3"
        run(f'ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=stereo -t 30 "{silent}"')
        music_choice = str(silent)
    mixed_audio = TMP_DIR / f"mixed_{stamp}.mp3"
    print("Mixing audio...")
    mix_audio(str(voice_file), music_choice, str(mixed_audio))
    audio_dur = get_audio_duration(str(mixed_audio)) or 12.0
    srt_file = TMP_DIR / f"sub_{stamp}.srt"
    create_srt_from_script(script, audio_dur, srt_file)
    # Image generation: try IA then fallback
    img_path = TMP_DIR / f"img_{stamp}.jpg"
    prompt = f"{hooks[0]} - editorial photo, cinematic, high detail, no watermark"
    generate_image_with_ia(prompt, img_path)
    main_video = TMP_DIR / f"main_{stamp}.mp4"
    create_center_image_and_video(title, mixed_audio, main_video)
    burned_main = TMP_DIR / f"burned_main_{stamp}.mp4"
    burn_subtitles_to_video(main_video, srt_file, burned_main)
    hook_clip = TMP_DIR / f"hook_{stamp}.mp4"
    make_hook_clip(hooks[0], hook_clip, seconds=3)
    final_video = OUT_DIR / f"tiktok_{stamp}.mp4"
    concat_videos_mp4([hook_clip, burned_main], final_video)
    meta_path = OUT_DIR / f"meta_{stamp}.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    caption = f"{title}\n\nHooks:\n- {hooks[0]}\n- {hooks[1]}\n- {hooks[2]}\n\nHashtags: {' '.join(hashtags)}"
    if send_telegram:
        print("Sending to Telegram:", final_video)
        ok = send_to_telegram(str(final_video), caption=caption)
        print("Telegram sent:", ok)
    return {"video": str(final_video), "meta": meta}

if __name__ == "__main__":
    param_topic = None
    if len(sys.argv) > 1:
        param_topic = " ".join(sys.argv[1:])
    out = create_full_reel(topic=param_topic, send_telegram=True)
    print(json.dumps(out, ensure_ascii=False, indent=2))
