# Auto Reels - Proyecto automático para Termux / VPS

Este proyecto genera vídeos verticales (9:16) automáticamente: guion, hooks, TTS, subtítulos, imagen (IA o fallback), mezcla de audio y envío a Telegram.

## Estructura
```
auto_reels_project/
  generate_full_reel.py
  .env.example
  topics.txt
  requirements.txt
  README.md
```

## Requisitos (Termux)
- pkg install python ffmpeg
- pip install -r requirements.txt

## Instalación rápida en Termux
```bash
mkdir -p ~/auto_reels && cd ~/auto_reels
# copia generate_full_reel.py aquí (o usa scp)
# crea .env basado en .env.example
pip install --upgrade pip
pip install -r requirements.txt
mkdir music out tmp
# añade mp3s a music/ si quieres
python3 generate_full_reel.py
```

## Uso
- Ejecuta `python3 generate_full_reel.py` para generar un vídeo y enviarlo a Telegram (si .env tiene BOT_TOKEN y CHAT_ID).
- Para ejecución automática diaria, usa cronie o systemd timer (en VPS).

## Notas
- Si no tienes tokens de IA, el script usa un fallback con Pillow para generar imágenes de texto sobre fondo.
- Si tu ffmpeg no soporta `subtitles` filter, la quema de subtítulos puede fallar; en ese caso el script aún genera archivos .srt en tmp/.
