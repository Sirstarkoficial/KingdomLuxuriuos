const { SlashCommandBuilder } = require("discord.js");
const fetchPrices = require("../utils/fetchPrices");
const getFlip = require("../utils/flip");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("flip")
    .setDescription("Busca la mejor ganancia comprando y vendiendo")
    .addStringOption(opt =>
      opt.setName("item").setDescription("Nombre del objeto").setRequired(true)
    ),
  async execute(interaction) {
    await interaction.deferReply();
    const item = interaction.options.getString("item");
    const data = await fetchPrices(item, ["Bridgewatch","Martlock","Lymhurst","FortSterling","Thetford"]);
    const best = getFlip(data);

    if (!best) return interaction.editReply("No hay flips rentables.");

    interaction.editReply(`💰 Mejor flip:
Ciudad: ${best.city}
Compra: ${best.buy_price_max}
Venta: ${best.sell_price_min}
Ganancia: ${best.profit}`);
  }
};
