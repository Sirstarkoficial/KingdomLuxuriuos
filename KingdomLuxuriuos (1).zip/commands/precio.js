const { SlashCommandBuilder } = require("discord.js");
const fetchPrices = require("../utils/fetchPrices");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("precio")
    .setDescription("Consulta precios de Albion Online")
    .addStringOption(opt =>
      opt.setName("item").setDescription("Nombre del objeto").setRequired(true)
    ),
  async execute(interaction) {
    await interaction.deferReply();
    const item = interaction.options.getString("item");
    const data = await fetchPrices(item, ["Bridgewatch","Martlock","Lymhurst","FortSterling","Thetford"]);

    if (!data.length) return interaction.editReply("No se encontraron datos.");

    let txt = `📦 Precios de **${item}**:
`;
    for (let a of data) {
      txt += `🏙 **${a.city}** → Compra ${a.buy_price_max} / Venta ${a.sell_price_min}
`;
    }

    interaction.editReply(txt);
  }
};
