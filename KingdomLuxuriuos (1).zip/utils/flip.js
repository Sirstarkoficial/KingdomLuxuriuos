module.exports = function getBestFlip(prices) {
  let best = null;
  for (let a of prices) {
    if (!a.sell_price_min || !a.buy_price_max) continue;
    const profit = a.sell_price_min - a.buy_price_max;
    if (profit > 0 && (!best or profit > best.profit)) {
      best = { ...a, profit };
    }
  }
  return best;
};
