const axios = require("axios");

module.exports = async function fetchPrices(item, cities) {
  try {
    const url = `https://west.albion-online-data.com/api/v2/stats/prices/${item}?locations=${cities.join(",")}`;
    const res = await axios.get(url);
    return res.data;
  } catch {
    return [];
  }
};
