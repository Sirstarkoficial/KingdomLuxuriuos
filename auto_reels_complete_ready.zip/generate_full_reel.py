#!/usr/bin/env python3
# generate_full_reel.py
# Complete Auto Reels script (Termux-ready)
# Features:
# - Daily auto-topic (curiosidades)
# - Auto guion + hooks + hashtags
# - TTS (gTTS)
# - Pillow image fallback (uses textbbox)
# - Mix audio with ffmpeg
# - Generate .srt subtitles and burn them
# - Create short hook clip and concat
# - Send final video to Telegram
# - Robust error handling and temp cleanup

import os, sys, re, json, random, subprocess, shlex
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from gtts import gTTS
from PIL import Image, ImageDraw, ImageFont

# Directories (Termux-friendly)
ROOT = Path.home() / "auto_reels"
MUSICS = ROOT / "musics"
TMP = ROOT / "tmp"
OUT = ROOT / "out"
for p in (ROOT, MUSICS, TMP, OUT):
    p.mkdir(parents=True, exist_ok=True)

# Load .env (prefer ROOT/.env, else local .env)
env_path = ROOT / ".env"
if not env_path.exists():
    env_path = Path(__file__).parent / ".env"
if env_path.exists():
    load_dotenv(dotenv_path=str(env_path))

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
CHAT_ID = os.getenv("CHAT_ID", "").strip()
VOICE_LANG = os.getenv("VOICE_LANG", "es")
VIDEO_W = int(os.getenv("VIDEO_WIDTH", "1080"))
VIDEO_H = int(os.getenv("VIDEO_HEIGHT", "1920"))

def run(cmd, capture=False):
    try:
        if capture:
            out = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            return out.decode('utf-8', errors='ignore')
        else:
            subprocess.check_call(cmd)
            return True
    except subprocess.CalledProcessError as e:
        print("Command failed:", e)
        if capture:
            return e.output.decode('utf-8', errors='ignore')
        return False

# --- Topic / script / hooks generators ---
SEED = ["curiosidades", "hechos curiosos", "datos sorprendentes", "ciencia curiosa", "historia curiosa"]
def auto_topic():
    key = datetime.now().strftime("%Y-%m-%d")
    rnd = random.Random(key)
    seed = rnd.choice(SEED)
    templates = [
        "Curiosidades sobre {} que no sabías",
        "5 datos curiosos de {}",
        "¿Sabías esto sobre {}?",
        "Lo más sorprendente de {} en 60s"
    ]
    return rnd.choice(templates).format(seed)

def generate_script(topic):
    intro = f"¿Sabías esto sobre {topic}? Te doy 3 datos rápidos."
    bullets = [
        f"Primero: un dato curioso sobre {topic}.",
        f"Segundo: otro dato que sorprende sobre {topic}.",
        f"Tercero: una conclusión breve y práctica."
    ]
    cta = "Si te gustó guarda y sígueme para más curiosidades."
    full = " ".join([intro] + bullets + [cta])
    title = f"{topic} - Curiosidades rápidas"
    return title, full

def generate_hooks_and_hashtags(script_text, topic):
    words = re.findall(r"\w{4,}", (script_text + " " + topic).lower())
    kws = list(dict.fromkeys(words))[:5]
    hooks = [
        f"Nadie te dice esto sobre {topic}…",
        f"3 datos rápidos de {topic} que te sorprenderán",
        f"¿Conoces estos secretos de {topic}?"
    ]
    hashtags = ["#Curiosidades", "#DatoCurioso", "#ParaTi", "#Reels"]
    if kws:
        hashtags.append("#" + kws[0])
    return hooks, hashtags

# --- TTS ---
def text_to_speech(text, out_mp3, lang=VOICE_LANG):
    try:
        tts = gTTS(text, lang=lang)
        tts.save(str(out_mp3))
        return out_mp3
    except Exception as e:
        print("TTS failed:", e)
        raise

# --- Image creation (Pillow fallback) using textbbox ---
def get_font(size=64):
    candidates = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/system/fonts/DroidSansFallback.ttf"]
    for p in candidates:
        try:
            return ImageFont.truetype(p, size=size)
        except Exception:
            continue
    return ImageFont.load_default()

def create_image_with_text(text, out_img, size=(VIDEO_W, VIDEO_H), font_path=None):
    img = Image.new("RGB", size, color=(18,18,18))
    draw = ImageDraw.Draw(img)
    font = get_font(64 if not font_path else 72)
    # wrap text to lines
    words = text.split()
    lines = []
    cur = ""
    for w in words:
        if len(cur + " " + w) > 20:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur: lines.append(cur)
    # vertical start
    total_h = 0
    bboxes = []
    for line in lines[:6]:
        bbox = draw.textbbox((0,0), line, font=font)
        h = bbox[3] - bbox[1]
        bboxes.append((bbox, h))
        total_h += h + 12
    y = (size[1] - total_h) // 2
    for i, line in enumerate(lines[:6]):
        bbox, h = bboxes[i]
        tw = bbox[2] - bbox[0]
        draw.text(((size[0]-tw)//2, y), line, font=font, fill=(255,255,255))
        y += h + 12
    img.save(out_img, quality=85)
    return out_img

# --- Audio helpers ---
def get_audio_duration(path):
    out = run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1", str(path)], capture=True)
    try:
        return float(out.strip().splitlines()[0])
    except Exception:
        return None

def mix_audio(voice_mp3, music_mp3, out_mp3, music_vol=0.25, voice_vol=1.0):
    if not music_mp3 or not Path(music_mp3).exists():
        run(["ffmpeg","-y","-i", str(voice_mp3), "-c:a","aac", str(out_mp3)])
        return out_mp3
    run(["ffmpeg","-y","-i", str(voice_mp3), "-stream_loop","-1","-i", str(music_mp3),
         "-filter_complex", f"[1:a]volume={music_vol}[m];[0:a]volume={voice_vol}[v];[v][m]amix=inputs=2:duration=first:dropout_transition=2[a]",
         "-map","[a]","-c:a","aac","-b:a","192k", str(out_mp3)])
    return out_mp3

# --- Subtitles creation (.srt) ---
def create_srt(script_text, audio_duration, srt_path):
    parts = [p.strip() for p in re.split(r'[\\.\\!\\?]+', script_text) if p.strip()]
    if not parts:
        parts = [script_text]
    total_words = sum(len(p.split()) for p in parts)
    wps = max(2.5, total_words / max(0.1, audio_duration))
    t = 0.5
    with open(srt_path, "w", encoding="utf-8") as f:
        idx = 1
        for p in parts:
            w = len(p.split())
            dur = max(0.8, w / wps)
            start = t
            end = t + dur
            def fmt(x):
                h = int(x//3600); m = int((x%3600)//60); s = int(x%60); ms = int((x-int(x))*1000)
                return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
            f.write(f"{idx}\n{fmt(start)} --> {fmt(end)}\n{p}\n\n")
            idx += 1
            t = end + 0.12
    return srt_path

# --- Video creation helpers ---
def make_video_from_image_and_audio(image_path, audio_path, out_video):
    dur = get_audio_duration(audio_path) or 10
    run(["ffmpeg","-y","-loop","1","-i", str(image_path), "-i", str(audio_path),
         "-c:v","libx264","-tune","stillimage","-vf", f"scale={VIDEO_W}:{VIDEO_H},format=yuv420p",
         "-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart","-t", str(dur), str(out_video)])
    return out_video

def burn_subtitles_to_video(input_video, srt_file, out_video):
    # Use subtitles filter simply (avoid complex quoting)
    run(["ffmpeg","-y","-i", str(input_video), "-vf", f"subtitles={srt_file}", "-c:a","copy", str(out_video)])
    return out_video

def make_hook_clip(text, out_hook, seconds=3):
    hook_img = TMP / f"hook_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg"
    create_image_with_text(text, hook_img, size=(VIDEO_W, VIDEO_H))
    run(["ffmpeg","-y","-loop","1","-i", str(hook_img), "-c:v","libx264","-t", str(seconds),
         "-vf", f"scale={VIDEO_W}:{VIDEO_H},format=yuv420p", "-pix_fmt","yuv420p", "-movflags","+faststart", str(out_hook)])
    return out_hook

def concat_videos(list_of_files, out_file):
    concat_txt = TMP / "concat_list.txt"
    with open(concat_txt, "w", encoding="utf-8") as f:
        for p in list_of_files:
            f.write(f"file '{p}'\n")
    run(["ffmpeg","-y","-f","concat","-safe","0","-i", str(concat_txt), "-c","copy", str(out_file)])
    return out_file

# --- Telegram sending ---
def send_to_telegram(file_path, caption=""):
    if not BOT_TOKEN or not CHAT_ID:
        print("BOT_TOKEN/CHAT_ID not set; skipping Telegram send.")
        return False
    try:
        import requests
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
        with open(file_path, "rb") as f:
            files = {"document": f}
            data = {"chat_id": CHAT_ID, "caption": caption}
            r = requests.post(url, data=data, files=files, timeout=180)
            print("Telegram response:", r.status_code)
            return r.ok
    except Exception as e:
        print("Telegram send failed:", e)
        return False

# --- Orchestrator ---
def create_full_reel(topic=None, send_telegram=True):
    topic = topic or auto_topic()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    title, script = generate_script(topic)
    hooks, hashtags = generate_hooks_and_hashtags(script, topic)
    meta = {"topic": topic, "title": title, "script": script, "timestamp": stamp, "hooks": hooks, "hashtags": hashtags}
    try:
        voice = TMP / f"voice_{stamp}.mp3"
        print("Generating TTS...")
        text_to_speech(script, voice)
        # choose music
        mus = list(Path(MUSICS).glob("*.mp3")) + list(Path(MUSICS).glob("*.wav"))
        music_choice = str(random.choice(mus)) if mus else None
        if not music_choice:
            # fallback to included silence wav if exists in /mnt/data
            fallback = Path("/mnt/data/silence_30s.wav")
            if fallback.exists():
                music_choice = str(fallback)
        mixed = TMP / f"mixed_{stamp}.mp3"
        mix_audio(voice, music_choice, mixed)
        audio_dur = get_audio_duration(mixed) or 12.0
        srt = TMP / f"sub_{stamp}.srt"
        create_srt(script, audio_dur, srt)
        img = TMP / f"img_{stamp}.jpg"
        # try to create an image (fallback)
        create_image_with_text(title, img)
        main = TMP / f"main_{stamp}.mp4"
        make_video_from_image_and_audio(img, mixed, main)
        burned = TMP / f"burned_{stamp}.mp4"
        burn_subtitles_to_video(main, srt, burned)
        hook = TMP / f"hook_{stamp}.mp4"
        make_hook_clip(hooks[0], hook, seconds=3)
        final = OUT / f"reel_{stamp}.mp4"
        concat_videos([str(hook), str(burned)], final)
        meta_path = OUT / f"meta_{stamp}.json"
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        caption = f"{title}\n\n{hooks[0]}\n\n{' '.join(hashtags)}"
        if send_telegram:
            send_to_telegram(str(final), caption=caption)
        return {"video": str(final), "meta": meta}
    except Exception as e:
        print("Error creating reel:", e)
        return {"error": str(e)}

if __name__ == "__main__":
    param = None
    if len(sys.argv) > 1:
        param = " ".join(sys.argv[1:])
    out = create_full_reel(topic=param, send_telegram=True)
    print(json.dumps(out, ensure_ascii=False, indent=2))
